﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OSI.Core.Models.Responses
{
    public class GenerateOtpResponse
    {
        public bool Success { get; set; }

        public string Message { get; set; }
    }
}
