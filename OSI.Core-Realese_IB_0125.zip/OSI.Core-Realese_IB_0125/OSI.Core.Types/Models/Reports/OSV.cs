﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OSI.Core.Models.Reports
{
    public class OSV
    {
        public List<OSVAbonent> Abonents { get; set; }
    }
}
