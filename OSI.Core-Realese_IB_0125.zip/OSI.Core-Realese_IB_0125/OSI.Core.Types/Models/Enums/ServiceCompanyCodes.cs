﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OSI.Core.Models.Enums
{
    public enum ServiceCompanyCodes
    {
        ELECTRIC, 
        GAZMAN, 
        LIFTER, 
        PLUMBER,
        DISPATCHER, 
        BOILERMAKER, 
        DISTRICT_INSPECTOR
    }
}
